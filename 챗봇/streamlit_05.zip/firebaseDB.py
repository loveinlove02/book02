import firebase_admin
from firebase_admin import credentials
from firebase_admin import db, storage

cred = credentials.Certificate('firebase3.json')
firebase_admin.initialize_app(cred, {
    'databaseURL': 'https://water-7f5cb.firebaseio.com/',
    'storageBucket' : 'water-7f5cb.appspot.com'
})

def get_book(isbn):  # 9791186697726
    ref = db.reference('library/book/' + isbn)
    return ref.get()



# print(get_book('9791186697726'))