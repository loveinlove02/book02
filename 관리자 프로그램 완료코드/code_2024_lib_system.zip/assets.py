import tkinter as tk

class Assets():
    def __init__(self):
        # self.login_stud_icon = tk.PhotoImage(file='images/login_student_img.png')
        # self.login_admin_icon = tk.PhotoImage(file='images/admin_img.png')
        # self.add_stud_icon = tk.PhotoImage(file='images/add_student_img.png')
        # self.locked_icon = tk.PhotoImage(file='images/locked.png')
        # self.unlocked_icon = tk.PhotoImage(file='images/unlocked.png')
        # self.add_student_pic_icon = tk.PhotoImage(file='images/add_image.png')
        self.bg_color = '#273b7a'
        self.title_color = '#BDC3DE'