import tkinter as tk
import assets as asset

import welcomePage
import firebaseDB

from tkinter import messagebox
from tkinter.filedialog import askopenfilename, askdirectory
from tkinter.ttk import Combobox

from PIL import Image, ImageTk
from PIL import ImageDraw, ImageFont
from io import BytesIO



class AddStudnetPage(tk.Frame):
    def __init__(self, container):
        super().__init__(container)

        self.pic_path = tk.StringVar()
        self.pic_path.set('')

        self.grade_list = ['01', '02', '03']
        self.class_list = ['01', '02', '03', '04', '05', '06', '07', '08', '09']
        self.num_list  = ['01', '02', '03', '04', '05', '06', '07', '08', '09']

        self.assets = asset.Assets()
        self.create_widgets()

    def create_widgets(self):
        self.add_student_page_fm = tk.Frame(self, highlightbackground=self.assets.bg_color, highlightthickness=2)
        self.add_student_page_fm.pack(pady=10)
        self.add_student_page_fm.configure(width=640, height=580)


        # 타이틀 프레임
        self.title_frame = tk.Frame(self.add_student_page_fm, bg=self.assets.title_color)
        self.title_frame.place(x=0, y=0)
        self.title_frame.configure(width=635, height=45)


        # 이미지 프레임
        self.add_pic_section_fm = tk.Frame(self.add_student_page_fm, highlightbackground=self.assets.bg_color, highlightthickness=2)
        self.add_pic_section_fm.place(x=10, y=60, width=135, height=135)

        add_image = Image.open('images/add_image.png')
        resized_add_image = add_image.resize((135, 135), Image.LANCZOS)
        self.student_img = ImageTk.PhotoImage(resized_add_image)

        self.add_pic_btn = tk.Button(self.add_pic_section_fm, image=self.student_img, bd=0, command=self.open_pic)
        self.add_pic_btn.pack()

        # 아이디
        self.student_id_label = tk.Label(self.add_student_page_fm, text='아이디', font='arial 14 bold')
        self.student_id_label.place(x=180, y=68)

        self.student_id_ent = tk.Entry(self.add_student_page_fm, font='arial 14 bold', highlightbackground='#273b7a', highlightthickness=2)
        self.student_id_ent.insert(tk.END, 'stud_24_')
        self.student_id_ent.place(x=250, y=68, width=241)

        # 비밀번호
        self.student_pw_label = tk.Label(self.add_student_page_fm, text='PW', font='arial 14 bold')
        self.student_pw_label.place(x=180, y=108)

        self.student_pw_ent = tk.Entry(self.add_student_page_fm, font='arial 14 bold', highlightbackground='#273b7a', highlightthickness=2, show='*')
        self.student_pw_ent.place(x=250, y=108, width=241)

        # 이름
        self.student_name_label = tk.Label(self.add_student_page_fm, text='이름', font='arial 14 bold')
        self.student_name_label.place(x=180, y=148)

        self.student_name_ent = tk.Entry(self.add_student_page_fm, font='arial 14 bold', highlightbackground='#273b7a', highlightthickness=2)
        self.student_name_ent.place(x=250, y=148, width=241)


        # 학년
        self.student_grade_label = tk.Label(self.add_student_page_fm, text='학년', font='arial 14 bold')
        self.student_grade_label.place(x=180, y=188)

        self.grade_combo = Combobox(self.add_student_page_fm, font='arial 14 bold', state='readonly', 
                                   values=self.grade_list)
        self.grade_combo.place(x=250, y=188)

        # 반
        self.student_class_label = tk.Label(self.add_student_page_fm, text='반', font='arial 14 bold')
        self.student_class_label.place(x=180, y=228)

        self.class_combo = Combobox(self.add_student_page_fm, font='arial 14 bold', state='readonly', 
                                   values=self.class_list)
        self.class_combo.place(x=250, y=228)

        
        # 번호
        self.student_num_label = tk.Label(self.add_student_page_fm, text='번호', font='arial 14 bold')
        self.student_num_label.place(x=180, y=268)

        self.num_combo = Combobox(self.add_student_page_fm, font='arial 14 bold', state='readonly', 
                                   values=self.num_list)
        self.num_combo.place(x=250, y=268)


        # 아래쪽 프레임
        self.bottom_frame = tk.Frame(self.add_student_page_fm, bg='#F5EBDD')
        self.bottom_frame.place(x=0, y=452)
        self.bottom_frame.configure(width=635, height=120)


        # 버튼
        self.forward_book_reg_btn = tk.Button(self.bottom_frame, text='학생 등록', font='arial 25 bold', bg='#6C6DFF', fg='white', bd=0, command=self.forwad_to_student_reg)
        self.forward_book_reg_btn.place(x=110, y=26)


        # 버튼
        self.forward_welcome_btn = tk.Button(self.bottom_frame, text='시작 화면', font='arial 25 bold', bg='#FE853E', fg='white', bd=0, command=self.forwad_to_welcome_page)
        self.forward_welcome_btn.place(x=360, y=26)



    def open_pic(self):
        path = askopenfilename()

        if path:
            img = ImageTk.PhotoImage(Image.open(path).resize((100, 100)))
            self.pic_path.set(path)

            self.add_pic_btn.config(image=img)
            self.add_pic_btn.image = img


    def forwad_to_student_reg(self):
        local_image_path = self.pic_path.get()  # 이미지 경로
        remote_image_path = ''                  # 업로드 될 이미지 이름

        if local_image_path == '':
            messagebox.showwarning("경고", f"사진을 입력하세요")
            return
        
        if self.student_id_ent.get() == 'stud_24_':
            messagebox.showwarning("경고", f"아이디를 입력하세요")
            return
        
        remote_image_path = self.student_id_ent.get() + '.jpg'

        
        if self.student_pw_ent.get() == '':
            messagebox.showwarning("경고", f"비밀번호를 입력하세요")
            return
        
        if self.student_name_ent.get() == '':
            messagebox.showwarning("경고", f"이름을 입력하세요")
            return

        if self.grade_combo.get() == '':
            messagebox.showwarning("경고", f"학년을 입력하세요")
            return

        if self.class_combo.get() == '':
            messagebox.showwarning("경고", f"반을 입력하세요")
            return

        if self.num_combo.get() == '':
            messagebox.showwarning("경고", f"번호를 입력하세요")
            return
        
        student_info_data = {
            'id' : self.student_id_ent.get(),
            'pw' : self.student_pw_ent.get(), 
            'name' : self.student_name_ent.get(), 
            'grade' : self.grade_combo.get(), 
            'class' : self.class_combo.get(), 
            'num' : self.num_combo.get()         
        }

        # 이미지 업로드
        firebaseDB.upload_image(local_image_path, remote_image_path)   

        # 데이터 업로드
        firebaseDB.set_student_info(student_info_data)
        messagebox.showinfo("완료", f"완료")        

        # print(f'아이디 : {self.student_id_ent.get()}')
        # print(f'비밀번호: {self.student_pw_ent.get()}')
        # print(f'이름: {self.student_name_ent.get()}')
        # print(f'이미지 경로 : {remote_image_path}')
        # print(f'학년 : {self.grade_combo.get()}')    
        # print(f'반 : {self.class_combo.get()}')
        # print(f'번호 : {self.num_combo.get()}')
        # print(student_info_data)

    def forwad_to_welcome_page(self):
        self.add_student_page_fm.destroy()
        self.update()

        welcome_page_fm = welcomePage.WelcomePage(self)
        welcome_page_fm.pack()


# root = tk.Tk()
# root.title("Add Student")
# root.geometry("650x600")

# welcome_page = AddStudnetPage(root)
# welcome_page.pack(fill="both", expand=True)
# root.mainloop()

