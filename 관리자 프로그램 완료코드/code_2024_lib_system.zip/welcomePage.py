import tkinter as tk
import assets as asset
from PIL import Image, ImageTk

import addStudentPage
import addBookPage

import bookListPage
import studentListPage


class WelcomePage(tk.Frame):
    def __init__(self, container):
        super().__init__(container)

        self.assets = asset.Assets()
        self.create_widgets()

    def create_widgets(self):
        self.welcome_page_fm = tk.Frame(self, highlightbackground=self.assets.bg_color, highlightthickness=2)
        self.welcome_page_fm.pack(pady=10)
        self.welcome_page_fm.configure(width=640, height=580)

        # 타이틀 프레임
        self.title_frame = tk.Frame(self.welcome_page_fm, bg=self.assets.title_color)
        self.title_frame.place(x=0, y=0)
        self.title_frame.configure(width=635, height=45)
        # ---------------------------------------------------------------------------------

        # 도서 등록, 목록 이미지
        book1 = Image.open('images/book1.png')
        book2 = Image.open('images/book2.png')

        # 이미지 resize
        resized_image_book1 = book1.resize((150, 100), Image.LANCZOS)
        resized_image_book2 = book2.resize((150, 100), Image.LANCZOS)

        # tkinter에서 사용할 수 있는 형식으로 변환
        self.book_img_1 = ImageTk.PhotoImage(resized_image_book1)
        self.book_img_2 = ImageTk.PhotoImage(resized_image_book2)

        # 등록, 목록 버튼
        self.reg_btn = tk.Button(self.welcome_page_fm, image=self.book_img_1,  bd=0, 
                                 command=self.forward_to_add_book_page)
        self.reg_btn.place(x=100, y=120)

        self.list_btn = tk.Button(self.welcome_page_fm, image=self.book_img_2, bd=0, 
                                  command=self.forward_to_book_list_page)
        self.list_btn .place(x=370, y=120)
        # ---------------------------------------------------------------------------------

        # 레이블
        self.reg_label = tk.Label(self.welcome_page_fm, text= '도서 등록', font='arial 18', fg='#004BE5')
        self.reg_label.place(x=120, y=245)

        self.list_label = tk.Label(self.welcome_page_fm, text= '도서 목록', font='arial 18', fg='#004BE5')
        self.list_label.place(x=390, y=245)        
        # ---------------------------------------------------------------------------------

        # 학생 등록, 학생 목록 이미지
        student_book1 = Image.open('images/face.png')
        student_book2 = Image.open('images/face.png')

        # 이미지 resize
        resized_image_student1 = student_book1.resize((105, 100), Image.LANCZOS)
        resized_image_student2 = student_book2.resize((105, 100), Image.LANCZOS)

        # tkinter에서 사용할 수 있는 형식으로 변환
        self.student_img_1 = ImageTk.PhotoImage(resized_image_student1)
        self.student_img_2 = ImageTk.PhotoImage(resized_image_student2)

        # 등록, 목록 버튼
        self.student_reg_btn = tk.Button(self.welcome_page_fm, image=self.student_img_1,  bd=0, 
                                         command=self.forward_to_add_student_page)
        self.student_reg_btn.place(x=125, y=340)

        self.student_list_btn = tk.Button(self.welcome_page_fm, image=self.student_img_2, bd=0, 
                                          command=self.forward_to_student_list_page)
        self.student_list_btn .place(x=395, y=340)
        # ---------------------------------------------------------------------------------

        self.student_reg_label = tk.Label(self.welcome_page_fm, text= '학생 등록', font='arial 18', fg='#004BE5')
        self.student_reg_label.place(x=125, y=465)

        self.student_list_label = tk.Label(self.welcome_page_fm, text= '학생 목록', font='arial 18', fg='#004BE5')
        self.student_list_label.place(x=395, y=465)


    def forward_to_add_student_page(self):
        self.welcome_page_fm.destroy()
        self.update()

        add_student_fm = addStudentPage.AddStudnetPage(self)
        add_student_fm.pack()


    def forward_to_student_list_page(self):
        self.welcome_page_fm.destroy()
        self.update()

        student_list_fm = studentListPage.StudentListPage(self)
        student_list_fm.pack()

    def forward_to_add_book_page(self):
        self.welcome_page_fm.destroy()
        self.update()

        add_book_fm = addBookPage.AddBookPage(self)
        add_book_fm.pack()

    def forward_to_book_list_page(self):
        self.welcome_page_fm.destroy()
        self.update()

        book_list_fm = bookListPage.BookListPage(self)
        book_list_fm.pack()




# root = tk.Tk()
# root.title("Welcome Page")
# root.geometry("650x600")

# welcome_page = WelcomePage(root)
# welcome_page.pack(fill="both", expand=True)
# root.mainloop()

