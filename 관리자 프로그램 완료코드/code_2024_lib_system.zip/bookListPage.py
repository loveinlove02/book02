import tkinter as tk
from tkinter import ttk

import assets as asset
import welcomePage
import selectedBookInfoPage
import firebaseDB

from tkinter import messagebox

class BookListPage(tk.Frame):
    def __init__(self, container):
        super().__init__(container)

        self.assets = asset.Assets()
        self.create_widgets()

    def create_widgets(self):
        self.book_list_page_fm = tk.Frame(self, highlightbackground=self.assets.bg_color, highlightthickness=2)
        self.book_list_page_fm.pack(pady=10)
        self.book_list_page_fm.configure(width=640, height=580)

        # 타이틀 프레임
        self.title_frame = tk.Frame(self.book_list_page_fm, bg=self.assets.title_color)
        self.title_frame.place(x=0, y=0)
        self.title_frame.configure(width=635, height=45)


        # Treeview 프레임
        self.treeview_section_fm = tk.Frame(self.book_list_page_fm, highlightbackground=self.assets.bg_color, highlightthickness=1)
        self.treeview_section_fm.place(x=10, y=110, width=620, height=300)

        # 세로 스크롤바 설정
        self.scrollbar_y = ttk.Scrollbar(self.treeview_section_fm, orient="vertical")
        self.scrollbar_y.pack(side=tk.RIGHT, fill="y")

        # Treeview 설정
        self.book_tree = ttk.Treeview(self.treeview_section_fm, 
                                      columns=("제목", "저자", "출판사", "isbn", "대출상태"), 
                                      show="headings",
                                      yscrollcommand=self.scrollbar_y.set)
        self.book_tree.pack(side=tk.LEFT, fill="both", expand=True)

        # Treeview와 스크롤바 연결
        self.scrollbar_y.config(command=self.book_tree.yview)

        # 각 열 설정
        self.book_tree.heading("제목", text="제목")
        self.book_tree.heading("저자", text="저자")
        self.book_tree.heading("출판사", text="출판사")
        self.book_tree.heading("isbn", text="isbn")
        self.book_tree.heading("대출상태", text="대출상태")

        self.book_tree.column("제목", anchor="center", width=150)
        self.book_tree.column("저자", anchor="center", width=80)
        self.book_tree.column("출판사", anchor="center", width=120)
        self.book_tree.column("isbn", anchor="center", width=100)
        self.book_tree.column("대출상태", anchor="center", width=80)


        books = firebaseDB.get_book_list()

        # 예시 데이터 삽입
        # books = [
        #     ("책 제목 " + str(i), "저자 " + str(i), "출판사 " + str(i), "9791169210027", "대출가능" if i % 2 == 0 else "대출중")
        #     for i in range(1, 51)
        # ]

        for book in books:
            self.book_tree.insert("", "end", values=book)



        # 아래쪽 프레임
        self.bottom_frame = tk.Frame(self.book_list_page_fm, bg='#F5EBDD')
        self.bottom_frame.place(x=0, y=452)
        self.bottom_frame.configure(width=635, height=120)
        
        # 버튼
        self.forward_welcome_btn = tk.Button(self.bottom_frame, text='시작 화면', font='arial 25 bold', bg='#FE853E',
                                             fg='white', bd=0, command=self.forwad_to_welcome_page)
        self.forward_welcome_btn.place(x=240, y=26)

        self.book_tree.bind("<ButtonRelease-1>", self.on_item_click)

    def on_item_click(self, event):
        item = self.book_tree.identify_row(event.y)  # 클릭한 행의 ID를 가져옵니다.
        if not item:
            return

        # 클릭한 셀의 값 가져오기
        column = self.book_tree.identify_column(event.x)
        column_id = column.split("#")[-1]
        column_index = int(column_id) - 1
        
        if column_index == 3:  # ISBN 열의 인덱스 (0부터 시작)
            isbn = self.book_tree.item(item, "values")[column_index]
            # messagebox.showinfo("ISBN 정보", f"ISBN: {isbn}")
            messagebox.showinfo('이동', '상세보기로 이동합니다')
            self.forward_to_selected_book_info_page(isbn)   

    def forwad_to_welcome_page(self):
        self.book_list_page_fm.destroy()
        self.update()

        welcome_page_fm = welcomePage.WelcomePage(self)
        welcome_page_fm.pack()

    def forward_to_selected_book_info_page(self, isbn):
        self.book_list_page_fm.destroy()
        self.update()

        selected_book_info_page_fm = selectedBookInfoPage.SelectedBookInfoPage(self, isbn)
        selected_book_info_page_fm.pack()