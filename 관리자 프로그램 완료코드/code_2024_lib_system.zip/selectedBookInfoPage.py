import tkinter as tk
from tkinter import ttk

import assets as asset
import welcomePage
import bookListPage
import firebaseDB

from PIL import Image, ImageTk
import requests
from io import BytesIO

class SelectedBookInfoPage(tk.Frame):
    def __init__(self, container, isbn):
        super().__init__(container)
        
        self.book_isbn = isbn
        self.book_info_firebase = firebaseDB.get_book_info(isbn)
        # print(self.book_info_firebase)
        
        self.assets = asset.Assets()
        self.create_widgets()

    def create_widgets(self):
        self.selected_book_info_page_fm = tk.Frame(self, highlightbackground=self.assets.bg_color, highlightthickness=2)
        self.selected_book_info_page_fm.pack(pady=10)
        self.selected_book_info_page_fm.configure(width=640, height=580)

        # 타이틀 프레임
        self.title_frame = tk.Frame(self.selected_book_info_page_fm, bg=self.assets.title_color)
        self.title_frame.place(x=0, y=0)
        self.title_frame.configure(width=635, height=45)
        # --------------------------------------------------------------------------------------    

        # 이미지 url
        url = self.book_info_firebase['image']

        # 이미지 요청 및 불러오기
        response = requests.get(url)
        img_data = response.content
        img = Image.open(BytesIO(img_data))

        # 이미지 크기를 100x100으로 조정
        img = img.resize((120, 120), Image.LANCZOS)

        # Tkinter에서 사용할 수 있는 이미지 객체로 변환
        self.book_img = ImageTk.PhotoImage(img)  

        # 레이블에 이미지 설정 및 배치
        self.book_image_label = tk.Label(self.selected_book_info_page_fm, image=self.book_img)
        self.book_image_label.place(x=10, y=50)


        # 제목, 저자, 춣판사_출판일, 청구기호, 등록번호, 대출상태
        self.book_title_label = tk.Label(self.selected_book_info_page_fm, text=self.book_info_firebase['title'], font='arial 14 bold')
        self.book_title_label.place(x=160, y=60)
        # ------------------------------------------------------------------------------------------------------------        
        self.book_author_label = tk.Label(self.selected_book_info_page_fm, text='저자', font='arial 14 bold')
        self.book_author_label.place(x=160, y=120)

        self.book_author_ent = tk.Entry(self.selected_book_info_page_fm, font='arial 14 bold', highlightbackground='#273b7a', highlightthickness=2)
        self.book_author_ent.insert(tk.END, self.book_info_firebase['author']) 
        self.book_author_ent.config(state='readonly')
        self.book_author_ent.place(x=250, y=120, width=280)
        # ------------------------------------------------------------------------------------------------------------
        self.book_publisher_label = tk.Label(self.selected_book_info_page_fm, text='출판사', font='arial 14 bold')
        self.book_publisher_label.place(x=160, y=180)

        self.book_publisher_ent = tk.Entry(self.selected_book_info_page_fm, font='arial 14 bold', highlightbackground='#273b7a', highlightthickness=2)
        self.book_publisher_ent.insert(tk.END, self.book_info_firebase['publisher']) 
        self.book_publisher_ent.config(state='readonly')
        self.book_publisher_ent.place(x=250, y=180, width=280)
        # ------------------------------------------------------------------------------------------------------------
        self.book_call_number_label = tk.Label(self.selected_book_info_page_fm, text='청구기호', font='arial 14 bold')
        self.book_call_number_label.place(x=160, y=240)

        self.book_call_number_ent = tk.Entry(self.selected_book_info_page_fm, font='arial 14 bold', highlightbackground='#273b7a', highlightthickness=2)
        self.book_call_number_ent.insert(tk.END, self.book_info_firebase['call_number']) 
        self.book_call_number_ent.config(state='readonly')
        self.book_call_number_ent.place(x=250, y=240, width=280)        
        # ------------------------------------------------------------------------------------------------------------
        self.book_access_number_label = tk.Label(self.selected_book_info_page_fm, text='등록번호', font='arial 14 bold')
        self.book_access_number_label.place(x=160, y=300)

        self.book_access_number_ent = tk.Entry(self.selected_book_info_page_fm, font='arial 14 bold', highlightbackground='#273b7a', highlightthickness=2)
        self.book_access_number_ent.insert(tk.END, self.book_info_firebase['access_number']) 
        self.book_access_number_ent.config(state='readonly')
        self.book_access_number_ent.place(x=250, y=300, width=280)
        # ------------------------------------------------------------------------------------------------------------
        self.book_borrow_state_label = tk.Label(self.selected_book_info_page_fm, text='대출상태', font='arial 14 bold')
        self.book_borrow_state_label.place(x=160, y=360)

        if self.book_info_firebase['borrow_state']=='N':
            borrow = '대출가능'
        else:
            borrow = '대출중'

        self.book_borrow_state_ent = tk.Entry(self.selected_book_info_page_fm, font='arial 14 bold', highlightbackground='#273b7a', highlightthickness=2)
        self.book_borrow_state_ent.insert(tk.END, borrow) 
        self.book_borrow_state_ent.config(state='readonly')
        self.book_borrow_state_ent.place(x=250, y=360, width=280)
        
        # ------------------------------------------------------------------------------------------------------------

        # 아래쪽 프레임
        self.bottom_frame = tk.Frame(self.selected_book_info_page_fm, bg='#F5EBDD')
        self.bottom_frame.place(x=0, y=452)
        self.bottom_frame.configure(width=635, height=120)
        
        # 버튼
        self.forward_book_list_btn = tk.Button(self.bottom_frame, text='이전 화면', font='arial 25 bold', bg='#6C6DFF',
                                             fg='white', bd=0, command=self.forwad_to_book_list_page)
        self.forward_book_list_btn.place(x=110, y=26)

        # 버튼
        self.forward_welcome_btn = tk.Button(self.bottom_frame, text='시작 화면', font='arial 25 bold', bg='#FE853E',
                                             fg='white', bd=0, command=self.forwad_to_welcome_page)
        self.forward_welcome_btn.place(x=360, y=26)



    def forwad_to_welcome_page(self):
        self.selected_book_info_page_fm.destroy()
        self.update()

        welcome_page_fm = welcomePage.WelcomePage(self)
        welcome_page_fm.pack()


    def forwad_to_book_list_page(self):
        self.selected_book_info_page_fm.destroy()
        self.update()

        book_list_page_fm = bookListPage.BookListPage(self)
        book_list_page_fm.pack()



# root = tk.Tk()
# root.title("SElected Book")
# root.geometry("650x600")

# welcome_page = SelectedBookInfoPage(root, '123456789')
# welcome_page.pack(fill="both", expand=True)
# root.mainloop()
