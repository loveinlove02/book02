import firebase_admin
from firebase_admin import credentials
from firebase_admin import db, storage

cred = credentials.Certificate('firebase.json')
firebase_admin.initialize_app(cred, {
    'databaseURL': 'https://cho2-9857c.firebaseio.com/',
    'storageBucket' : 'cho2-9857c.appspot.com'
})

def get_all_book():
    ref = db.reference('library/book/')
    book_dict = ref.get()

    f = open('data_document/book_document.txt', 'w', encoding='utf-8')

    for book_id, book in book_dict.items():
        title = book['title']
        author = book['author']
        publisher = book['publisher']
        call_number = book['call_number']
        access_number = book['access_number']
        location = book['location']
        isbn = book['isbn']

        print(f'### 제목 : {title}')
        print(f'- 저자 : {author}')
        print(f'- 발행처 : {publisher}')
        print(f'- isbn : {isbn}')
        print(f'- 청구기호 : {call_number}')
        print(f'- 등록번호 : {access_number}')
        print(f'- 소장위치 : {location}')
        print()
        print()

        f.write(f'### 제목 : {title}\n')
        f.write(f'- 저자 : {author}\n')
        f.write(f'- 발행처 : {publisher}\n')
        f.write(f'- isbn : {isbn}\n')
        f.write(f'- 청구기호 : {call_number}\n')
        f.write(f'- 등록번호 : {access_number}\n')
        f.write(f'- 소장위치 : {location}\n')
        f.write('\n\n')

    f.close()

    return True


    

    