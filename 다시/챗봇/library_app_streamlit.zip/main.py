import streamlit as st

st.set_page_config(
    page_title='도서 검색 챗봇', 
    page_icon='🎫'
)

st.title('도서 검색 챗봇')

