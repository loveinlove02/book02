import firebaseDB

firebaseDB.get_all_book()