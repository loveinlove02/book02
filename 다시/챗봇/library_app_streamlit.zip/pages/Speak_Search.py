import streamlit as st
from langchain_core.messages import ChatMessage
from langchain_openai import ChatOpenAI
from langchain_core.output_parsers import StrOutputParser
from langchain_text_splitters import RecursiveCharacterTextSplitter
from langchain.document_loaders import TextLoader
from langchain_community.vectorstores import FAISS
from langchain_core.runnables import RunnablePassthrough
from langchain_core.prompts import PromptTemplate
from langchain_openai import OpenAIEmbeddings

from whisper import whisper_stt
from openai import OpenAI
import base64


from dotenv import load_dotenv
import os

load_dotenv(verbose=True)
key = os.getenv('OPENAI_API_KEY')

# 캐시 디렉토리 생성
if not os.path.exists('.cache'):
    os.mkdir('.cache')

if not os.path.exists('.cache/files'):
    os.mkdir('.cache/files')

if not os.path.exists('.cache/embeddings'):
    os.mkdir('.cache/embeddings')

# 파일을 캐시해서 저장
@st.cache_resource(show_spinner='업로드한 파일을 처리 중입니다...')
def embed_file():      

    # ----------------------------------------------------------------------------
    # 단계 1: 문서 로드(Load Documents)
    loader = TextLoader("data_document/book_document.txt", encoding='utf-8')
    docs = loader.load()

    # 단계 2: 문서 분할(Split Documents)
    text_splitter = RecursiveCharacterTextSplitter(chunk_size=1000, chunk_overlap=50)
    split_documents = text_splitter.split_documents(docs)

    # 단계 3: 임베딩(Embedding) 생성
    embeddings = OpenAIEmbeddings()

    # 단계 4: DB 생성(Create DB) 및 저장
    # 벡터스토어를 생성합니다.
    vectorstore = FAISS.from_documents(documents=split_documents, embedding=embeddings)
    
    # 단계 5: 검색기(Retriever) 생성
    # 문서에 포함되어 있는 정보를 검색하고 생성합니다.
    retriever = vectorstore.as_retriever()

    return retriever

def create_chain(retriever):
    prompt = PromptTemplate.from_template(
        """You are an assistant for question-answering tasks. 
    Use the following pieces of retrieved context to answer the question.
    Please include the title, author, publisher, isbn, claim code, registration number, and place of collection in the answer. 
    If you don't know the answer, just say that 0.
    Answer in Korean.

    #Question: 
    {question} 
    #Context: 
    {context} 

    #Answer:"""
    )

    # 단계 7: 언어모델(LLM) 생성
    # 모델(LLM) 을 생성합니다.
    llm = ChatOpenAI(
        api_key=key, 
        model_name='gpt-4o-mini',  	# 모델 : 사용할 모델을 지정합니다.
        temperature=0,			    # 창의성 : (0.0 ~ 2.0) 
        max_tokens=2048,			# 최대 토큰 수
    )

    # 단계 8: 체인(Chain) 생성
    chain = (
        {"context": retriever, "question": RunnablePassthrough()}  #  itemgetter('question')
        | prompt
        | llm
        | StrOutputParser()
    )

    return chain

def text_to_audtio(client, text):
    response = client.audio.speech.create(
        model="tts-1",
        voice="alloy",
        input=text,
    )

    response.stream_to_file("audio.mp3")

def autoplay_audio(file_path: str):
    with open(file_path, "rb") as f:
        data = f.read()
        b64 = base64.b64encode(data).decode()
        md = f"""
            <audio controls autoplay="true">
            <source src="data:audio/mp3;base64,{b64}" type="audio/mp3">
            </audio>
            """
        st.markdown(
            md,
            unsafe_allow_html=True,
        )


st.title('💬 음성 검색 Chatbot')

if 'messages1' not in st.session_state:
    st.session_state['messages1'] = []

if 'chain' not in st.session_state:
    retriever = embed_file()
    chain = create_chain(retriever)
    st.session_state['chain'] = chain

with st.sidebar:
    clear_btn = st.button('chat clear')

def print_messages():
    for chat_message in st.session_state['messages1']:
        with st.chat_message(chat_message.role):
            st.write(chat_message.content)


def add_message(role, message):
    st.session_state['messages1'].append(ChatMessage(role=role, content=message))


if clear_btn:
    st.session_state['messages1'] = []

print_messages()

user_input = whisper_stt(openai_api_key=key, language = 'ko')
# user_input = st.chat_input('궁금한 내용을 물어보세요')

warning_msg = st.empty()  # 경고 메시지 띄위기 위한 빈 영역을 잡는다

user_input_container = st.empty()

if user_input:       

    user_input_container.write('')

    chain = st.session_state['chain']   # 체인을 만든다.
    
    if chain is not None:
        with st.chat_message('user'):
            st.write(user_input)        

        response = chain.invoke(user_input)

        if response!='0':
            client = OpenAI(api_key=key)    
            text_to_audtio(client, response)    # response 글을 audio.mp3 만든다 

            with st.chat_message('assistant'):
                st.write(response)

            autoplay_audio("audio.mp3")         # audio.mp3 자동으로 플레이

            add_message('user', user_input)
            add_message('assistant', response)
        else:
            response = '찾는 책은 없습니다.'
            
            client = OpenAI(api_key=key)    
            text_to_audtio(client, response)    # response 글을 audio.mp3 만든다

            with st.chat_message('assistant'):
                st.write(response)

            autoplay_audio("audio.mp3")         # audio.mp3 자동으로 플레이
            
            add_message('user', user_input)
            add_message('assistant', response)

        