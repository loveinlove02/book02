import firebase_admin
from firebase_admin import credentials
from firebase_admin import db, storage

from datetime import datetime


cred = credentials.Certificate('firebase.json')
firebase_admin.initialize_app(cred, {
    'databaseURL': 'https://cho2-9857c.firebaseio.com/',
    'storageBucket' : 'cho2-9857c.appspot.com'
})

def download_image():
    ref = db.reference('library/member')
    users_id = list(ref.get().keys())

    bucket = storage.bucket()
    local_path = 'download_image'

    for remote_path in users_id:
        print(remote_path)
        get_blob = bucket.blob(remote_path + '.jpg')
        get_blob.download_to_filename(local_path + '/' + remote_path + '.jpg')
        # print(remote_path + '.jpg', '다운로드')


def verify_student(code):
    ref = db.reference('library/member/' + code)
    return ref.get()


def get_student_id():
    ref = db.reference('library/member')
    users_id = list(ref.get().keys())
    return users_id


def get_student_password(student_id):
    ref = db.reference('library/member/' + student_id)
    return ref.get()['pw']


# 등록된 도서의 id를 리스트로 리턴
def get_book_id_list():
    ref = db.reference('library/book/')
    book_id_list = []

    for book_id in ref.get():
        book_id_list.append(book_id)

    return book_id_list

def get_book_info(book_id):
    ref = db.reference('library/book/' + book_id)
    book_info_dict = ref.get()

    return book_info_dict


def borrow_book(book_dict, user_id):
    
    now = datetime.now()
    borrow_date = now.strftime('%Y-%m-%d %H:%M')

    for book_id in book_dict:
        ref = db.reference('library/book/'+ book_id)
        # print(ref.get()['borrow_date'], ref.get()['borrow_state'], ref.get()['borrower_id'])
        ref.update({
            'borrow_date': borrow_date,
            'borrow_state': 'Y',
            'borrower_id': user_id
        })








def return_book(book_dict):
    for book_id in book_dict:
        ref = db.reference('library/book/'+ book_id)

        ref.update({
            'borrow_date': 'N',
            'borrow_state': 'N',
            'borrower_id': 'N'
        })