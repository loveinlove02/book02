import tkinter as tk
import welcomePage


class App(tk.Tk):
    def __init__(self):
        super().__init__()
        
        self.title('student management system')
        self.geometry('650x600')
        self.resizable(False, False)

        self.create_widgets()


    def create_widgets(self):
        welcome_page_frame = welcomePage.WelcomePage(self) 
        welcome_page_frame.pack()


if __name__ == "__main__":
    app = App()
    app.mainloop()