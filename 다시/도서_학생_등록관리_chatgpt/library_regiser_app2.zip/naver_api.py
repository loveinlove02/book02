import requests

def get_book_info(isbn):
    # 네이버 API 인증 정보
    client_id = "TjPNNheScQJKvS0jn4qh"
    client_secret = "V7BIJh1WbO"

    # 네이버 도서 검색 API URL
    url = f"https://openapi.naver.com/v1/search/book.json?query={isbn}&d_isbn={isbn}"

    # 요청 헤더 설정
    headers = {
        "X-Naver-Client-Id": client_id,
        "X-Naver-Client-Secret": client_secret
    }

    # API 요청 보내기
    response = requests.get(url, headers=headers)

    # 결과 출력
    if response.status_code == 200:
        result = response.json()

        if result['items']:
            return result['items'][0]
            # book = result['items'][0]
            # title = book['title']
            # author = book['author']
            # pubdate = book['pubdate']
            # publisher = book['publisher']


            # print(f"제목: {title}")
            # print(f"저자: {author}")
            # print(f"출판일: {pubdate}")
            # print(f'발행처: {publisher}')
            
        else:
            return []
    else:
        # print(f"Error Code: {response.status_code}")
        return []

