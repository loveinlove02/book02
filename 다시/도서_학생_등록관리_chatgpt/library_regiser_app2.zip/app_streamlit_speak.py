from dotenv import load_dotenv
import os
import streamlit as st
from langchain_core.messages import ChatMessage
from langchain_openai import ChatOpenAI
from langchain_core.output_parsers import StrOutputParser
from langchain_core.output_parsers import CommaSeparatedListOutputParser
from langchain_core.prompts import PromptTemplate
from langchain.embeddings import OpenAIEmbeddings
from langchain.vectorstores import Chroma
from openai import OpenAI
import base64

from whisper import whisper_stt


load_dotenv(verbose=True)
key = os.getenv('OPENAI_API_KEY')


# OpenAI의 임베딩 모델(text-embedding-ada-002)을 초기화.
embeddings = OpenAIEmbeddings(
    openai_api_key=key,
    model='text-embedding-ada-002'
)

database = Chroma(
    persist_directory = './data', 
    embedding_function = embeddings
)

st.title('💬 Chatbot')

# 처음 1번만 실행
if 'messages' not in st.session_state:
    # 대화기록을 저장하기 위한 용도
    st.session_state['messages'] = []


# 저장된 대화를 화면에 출력(이전 대화를 출력)
def print_messages():
    for chat_message in st.session_state['messages']:
        with st.chat_message(chat_message.role):
            st.write(chat_message.content)

# 새로운 메시지를 추가
def add_message(role, message):
    st.session_state['messages'].append(ChatMessage(role=role, content=message))            


def ask(query):    
    documents = database.similarity_search(query)	# 질문과 유사한 문서를 검색

    document_string = ''    

    for document in documents:						# 검색된 문서들을 document_string에 저장
        document_string += f"""
-------------------------------						
{document.page_content}
	"""
    template="""문장을 바탕으로 질문에 답하세요. 없으면 0이라고 답변하세요. 
    답변에는 제목, 저자, 발행처, isbn, 청구기호, 등록번호, 소장위치를 반듯이 넣어주세요.
    
    # 문장: {document}
    #질문: {query}
	"""

    prompt = PromptTemplate(
        template=template, 
        input_variables=['document', 'query']
    )

    llm = ChatOpenAI(
        api_key=key, 
        model='gpt-4o-mini',
        temperature=0
    )

    output_parser = StrOutputParser()
    
    chain = prompt | llm | output_parser

    return chain.invoke({'document': document_string, 'query': query})
# ----------------------------------------------------------------------

print_messages()

def text_to_audtio(client, text):
    response = client.audio.speech.create(
        model="tts-1",
        voice="alloy",
        input=text,
    )

    response.stream_to_file("audio.mp3")

def autoplay_audio(file_path: str):
    with open(file_path, "rb") as f:
        data = f.read()
        b64 = base64.b64encode(data).decode()
        md = f"""
            <audio controls autoplay="true">
            <source src="data:audio/mp3;base64,{b64}" type="audio/mp3">
            </audio>
            """
        st.markdown(
            md,
            unsafe_allow_html=True,
        )

user_input_container = st.empty()

# 사용자 입력
user_input = whisper_stt(openai_api_key=key, language = 'ko')
# user_input = st.chat_input('궁금한 내용을 물어보세요')

# 사용자 입력이 들어있으면
if user_input:
    # 입력된 내용을 바로 컨테이너에 표시
    user_input_container.write('')

    # 사용자 입력을 출력
    with st.chat_message('user'):
        st.write(user_input)
    
    response = ask(user_input)  

    if response!='0':                       # response 답변 내용 글
        client = OpenAI(api_key=key)    
        text_to_audtio(client, response)    # response 글을 audio.mp3 만든다  

        with st.chat_message('assistant'):  # response 글을 화면에 출력
            st.write(response)

        autoplay_audio("audio.mp3")         # audio.mp3 자동으로 플레이

        add_message('user', user_input)     # 대화내용 기록
        add_message('assistant', response)
    elif response=='0':
        client = OpenAI(api_key=key)
        text_to_audtio(client, '찾는 책은 없습니다')
        
        with st.chat_message('assistant'):
            st.write('찾는 책은 없습니다')

        autoplay_audio("audio.mp3")

        add_message('user', user_input)
        add_message('assistant', '찾는 책은 없습니다')