from dotenv import load_dotenv
import os
import streamlit as st
from langchain_core.messages import ChatMessage
from langchain_openai import ChatOpenAI
from langchain_core.output_parsers import StrOutputParser
from langchain_core.output_parsers import CommaSeparatedListOutputParser
from langchain_core.prompts import PromptTemplate
from langchain.embeddings import OpenAIEmbeddings
from langchain.vectorstores import Chroma
from openai import OpenAI
import base64

from whisper import whisper_stt

load_dotenv(verbose=True)
key = os.getenv('OPENAI_API_KEY')

st.title('💬 Chatbot')

def ask(query):
    llm = ChatOpenAI(api_key=key, model_name='gpt-4o-mini', temperature=0)
    prompt = PromptTemplate.from_template('{query}')
    output_parser = StrOutputParser()
    chain = prompt | llm | output_parser

    return chain.invoke({'query': query})

# 처음 1번만 실행
if 'messages' not in st.session_state:
    # 대화기록을 저장하기 위한 용도
    st.session_state['messages'] = []

user_input = st.chat_input('궁금한 내용을 물어보세요')

if user_input:
    with st.chat_message('user'):
        st.write(user_input)
    
    response = ask(user_input)

    with st.chat_message('assistant'):
        st.write(response)