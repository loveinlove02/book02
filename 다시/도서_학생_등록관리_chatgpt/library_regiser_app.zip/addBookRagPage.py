import tkinter as tk
import assets as asset

import welcomePage
import firebaseDB


from langchain.document_loaders import TextLoader
from langchain.text_splitter import SpacyTextSplitter
from langchain.embeddings import OpenAIEmbeddings
from langchain.vectorstores import Chroma

from dotenv import load_dotenv
import os

load_dotenv(verbose=True)
key = os.getenv('OPENAI_API_KEY')

from tkinter import messagebox

class AddBookRagPage(tk.Frame):
    def __init__(self, container):
        super().__init__(container)

        self.assets = asset.Assets()
        self.create_widgets()

    def create_widgets(self):
        self.add_book_rag_page_fm = tk.Frame(self, highlightbackground=self.assets.bg_color, highlightthickness=2)
        self.add_book_rag_page_fm.pack(pady=10)
        self.add_book_rag_page_fm.configure(width=640, height=580)

        # 타이틀 프레임
        self.title_frame = tk.Frame(self.add_book_rag_page_fm, bg=self.assets.title_color)
        self.title_frame.place(x=0, y=0)
        self.title_frame.configure(width=635, height=45)


        self.get_document_btn = tk.Button(self.add_book_rag_page_fm, text='문서 가져오기', font='arial 12 bold', 
                                          bg='#8C61D8', fg='white', bd=0, command=self.get_document)
        self.get_document_btn.place(x=10, y=60)

        self.rag_document_btn = tk.Button(self.add_book_rag_page_fm, text='문서 등록하기', font='arial 12 bold', 
                                          bg='#8C61D8', fg='white', bd=0, command=self.rag_document)
        self.rag_document_btn.place(x=10, y=100)

        
        # # 리스트 박스 추가
        # self.document_listbox = tk.Listbox(self.add_book_rag_page_fm, width=80, height=20)
        # self.document_listbox.place(x=10, y=140)

        # 리스트 박스 프레임 (스크롤바 포함)
        self.listbox_frame = tk.Frame(self.add_book_rag_page_fm)
        self.listbox_frame.place(x=10, y=140)

        # 스크롤바 추가
        self.scrollbar = tk.Scrollbar(self.listbox_frame)
        self.scrollbar.pack(side=tk.RIGHT, fill=tk.Y)

        # 리스트 박스 추가
        self.document_listbox = tk.Listbox(self.listbox_frame, width=80, height=20, yscrollcommand=self.scrollbar.set)
        self.document_listbox.pack(side=tk.LEFT)

        # 스크롤바가 리스트 박스와 연동되도록 설정
        self.scrollbar.config(command=self.document_listbox.yview)


        # 아래쪽 프레임
        self.bottom_frame = tk.Frame(self.add_book_rag_page_fm, bg='#F5EBDD')
        self.bottom_frame.place(x=0, y=452)
        self.bottom_frame.configure(width=635, height=120)

        # 버튼
        self.forward_welcome_btn = tk.Button(self.bottom_frame, text='시작 화면', font='arial 25 bold', bg='#FE853E',
                                             fg='white', bd=0, command=self.forwad_to_welcome_page)
        self.forward_welcome_btn.place(x=230, y=26)


    def forwad_to_welcome_page(self):
        self.add_book_rag_page_fm.destroy()
        self.update()

        welcome_page_fm = welcomePage.WelcomePage(self)
        welcome_page_fm.pack()


    def get_document(self):
        response = firebaseDB.get_all_book()

        if response:
            self.document_listbox.delete(0, tk.END)

            f = open('data_document/book_document.txt', 'r', encoding='utf-8')
            
            data = f.readlines()

            for i in data:
                print(i)
                self.document_listbox.insert(tk.END, i)

            f.close()

            messagebox.showinfo('완료', '완료')
        else:
            messagebox.showinfo('실패', '실패')


    def rag_document(self):
        documents = TextLoader("data_document/book_document.txt", encoding='utf-8').load()

        text_splitter = SpacyTextSplitter(		
            chunk_size=300, 					# 분할할 때 각 청크의 최대 길이를 300자로 설정
            pipeline='ko_core_news_sm'			# 분할에 사용할 한국어 모델인 ko_core_news_sm
        )

        splitted_documents = text_splitter.split_documents(documents)

        embeddings = OpenAIEmbeddings(
            openai_api_key=key,                     # OpenAI API 키를 사용하여 인증
            model='text-embedding-ada-002'          # OpenAI의 text-embedding-ada-002 모델을 사용하여 텍스트 임베딩을 생성
        )

        database = Chroma(                          # Chroma 벡터 스토어를 초기화
            persist_directory = './data',           # 임베딩 데이터를 저장할 디렉토리를 ./data로 설정
            embedding_function = embeddings         # embedding 함수로 위에서 만든 embeddings 객체 지정
        )

        database.add_documents(                     # 분할된 텍스트 조각들을 데이터베이스에 추가한다
            splitted_documents                      # 추가할 문서를 지정
        )

        print('완료')
        messagebox.showinfo('완료', '완료')
