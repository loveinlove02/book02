import tkinter as tk
from tkinter import ttk
import assets as asset

import welcomePage
import firebaseDB

from tkinter import messagebox

class StudentListPage(tk.Frame):
    def __init__(self, container):
        super().__init__(container)

        self.assets = asset.Assets()
        self.create_widgets()

    def create_widgets(self):
        self.student_list_page_fm = tk.Frame(self, highlightbackground=self.assets.bg_color, highlightthickness=2)
        self.student_list_page_fm.pack(pady=10)
        self.student_list_page_fm.configure(width=640, height=580)


        # 타이틀 프레임
        self.title_frame = tk.Frame(self.student_list_page_fm, bg=self.assets.title_color)
        self.title_frame.place(x=0, y=0)
        self.title_frame.configure(width=635, height=45)


        # Treeview 프레임
        self.treeview_section_fm = tk.Frame(self.student_list_page_fm, highlightbackground=self.assets.bg_color, highlightthickness=1)
        self.treeview_section_fm.place(x=10, y=110, width=620, height=300)

        # 세로 스크롤바 설정
        self.scrollbar_y = ttk.Scrollbar(self.treeview_section_fm, orient="vertical")
        self.scrollbar_y.pack(side=tk.RIGHT, fill="y")

        # Treeview 설정
        self.student_tree = ttk.Treeview(self.treeview_section_fm, 
                                         columns=("학번", "이름", "정보"), 
                                         show="headings",
                                         yscrollcommand=self.scrollbar_y.set)
        self.student_tree.pack(side=tk.LEFT, fill="both", expand=True)

        # Treeview와 스크롤바 연결
        self.scrollbar_y.config(command=self.student_tree.yview)

        # 각 열 설정
        self.student_tree.heading("학번", text="학번")
        self.student_tree.heading("이름", text="이름")
        self.student_tree.heading("정보", text="정보")

        self.student_tree.column("학번", anchor="center", width=150)
        self.student_tree.column("이름", anchor="center", width=150)
        self.student_tree.column("정보", anchor="center", width=280)

        # 학생 정보 가져오기
        students_list = firebaseDB.get_student_info()
        # print(students_list)
        

        # 학생 데이터 삽입
        for student in students_list:
            self.student_tree.insert("", "end", values=(student[0], student[2], str(student[3])+'학년 '+str(student[4])+'반 '+str(student[5])+'번'))


        self.student_tree.bind("<ButtonRelease-1>", self.on_item_click)


        # 아래쪽 프레임
        self.bottom_frame = tk.Frame(self.student_list_page_fm, bg='#F5EBDD')
        self.bottom_frame.place(x=0, y=452)
        self.bottom_frame.configure(width=635, height=120)


        # 버튼
        self.forward_welcome_btn = tk.Button(self.bottom_frame, text='시작 화면', font='arial 25 bold', bg='#FE853E',
                                             fg='white', bd=0, command=self.forwad_to_welcome_page)
        self.forward_welcome_btn.place(x=240, y=26)


    def on_item_click(self, event):
        item = self.student_tree.identify_row(event.y)  # 클릭한 행의 ID를 가져옵니다.
        
        if not item:
            return
        

        # 클릭한 셀의 값 가져오기
        column = self.student_tree.identify_column(event.x)
        column_id = column.split("#")[-1]
        column_index = int(column_id) - 1

        if column_index == 0:  # ISBN 열의 인덱스 (0부터 시작)
            id = self.student_tree.item(item, "values")[column_index]
            messagebox.showinfo("ID 정보", f"ID: {id}")



    def forwad_to_welcome_page(self):
        self.student_list_page_fm.destroy()
        self.update()

        welcome_page_fm = welcomePage.WelcomePage(self)
        welcome_page_fm.pack()



# root = tk.Tk()
# root.title("Student List")
# root.geometry("650x600")

# student_list_page = StudentListPage(root)
# student_list_page.pack(fill="both", expand=True)
# root.mainloop()

