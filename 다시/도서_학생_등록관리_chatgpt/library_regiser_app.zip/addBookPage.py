import tkinter as tk
import assets as asset

import welcomePage
import firebaseDB
import addBookRagPage

from tkinter import messagebox

import barcode
from barcode.writer import ImageWriter
import naver_api

from PIL import Image, ImageTk
import requests
from io import BytesIO


class AddBookPage(tk.Frame):
    def __init__(self, container):
        super().__init__(container)

        self.assets = asset.Assets()
        self.create_widgets()

    def create_widgets(self):
        self.add_book_page_fm = tk.Frame(self, highlightbackground=self.assets.bg_color, highlightthickness=2)
        self.add_book_page_fm.pack(pady=10)
        self.add_book_page_fm.configure(width=640, height=580)

        # 타이틀 프레임
        self.title_frame = tk.Frame(self.add_book_page_fm, bg=self.assets.title_color)
        self.title_frame.place(x=0, y=0)
        self.title_frame.configure(width=635, height=45)

        # isbn
        self.isbn_label = tk.Label(self.add_book_page_fm, text='ISBN', font='arial 14 bold')
        self.isbn_label.place(x=180, y=65)

        # isbn
        self.book_isbn_input_ent = tk.Entry(self.add_book_page_fm, font='arial 12', highlightbackground='#273b7a', highlightthickness=2)
        # self.book_isbn_input_ent.insert(tk.END, '123456789') 
        self.book_isbn_input_ent.focus()
        self.book_isbn_input_ent.place(x=250, y=65, width=368) 
        self.book_isbn_input_ent.bind('<Return>', self.input_entry_isbn)
        # ------------------------------------------------------------------------------------------------------

        # 이미지 프레임
        self.url = ''
        self.add_pic_section_fm = tk.Frame(self.add_book_page_fm, highlightbackground=self.assets.bg_color, highlightthickness=2)
        self.add_pic_section_fm.place(x=10, y=60, width=135, height=135)

        book1 = Image.open('images/book2.png')
        resized_image_book1 = book1.resize((120, 120), Image.LANCZOS)
        self.book_img = ImageTk.PhotoImage(resized_image_book1)

        self.add_pic_btn = tk.Button(self.add_pic_section_fm, image=self.book_img, bd=0)
        self.add_pic_btn.pack()
        # ------------------------------------------------------------------------------------------------------

        # 제목, 저자, 춣판사_출판일
        self.book_title_label = tk.Label(self.add_book_page_fm, text='제목', font='arial 14 bold')
        self.book_title_label.place(x=180, y=100)

        self.book_title_input_ent = tk.Entry(self.add_book_page_fm, font='arial 12', highlightbackground='#273b7a', highlightthickness=2)
        # self.book_title_input_ent.insert(tk.END, '혼자 공부하는 파이썬') 
        self.book_title_input_ent.place(x=250, y=100, width=368)     
        # ------------------------------------------------------------------------------------------------------

        # 저자
        self.book_author_label = tk.Label(self.add_book_page_fm, text='저자', font='arial 14 bold')
        self.book_author_label.place(x=180, y=140)

        self.book_author_input_ent = tk.Entry(self.add_book_page_fm, font='arial 12', highlightbackground='#273b7a', highlightthickness=2)
        # self.book_author_input_ent.insert(tk.END, '홍길동') 
        self.book_author_input_ent.place(x=250, y=140, width=368)     
        # ------------------------------------------------------------------------------------------------------

        # 출판사, 출판일
        self.book_publisher_label = tk.Label(self.add_book_page_fm, text='출판사', font='arial 14 bold')
        self.book_publisher_label.place(x=180, y=180)

        self.book_publisher_input_ent = tk.Entry(self.add_book_page_fm, font='arial 12', highlightbackground='#273b7a', highlightthickness=2)
        # self.book_publisher_input_ent.insert(tk.END, '한빛출판사 2022') 
        self.book_publisher_input_ent.place(x=250, y=180, width=368)  
        # ------------------------------------------------------------------------------------------------------

        # 등록번호
        self.book_access_number_label = tk.Label(self.add_book_page_fm, text='등록번호', font='arial 14 bold')
        self.book_access_number_label.place(x=180, y=220)

        self.book_access_number_input_ent = tk.Entry(self.add_book_page_fm, font='arial 12', highlightbackground='#273b7a', highlightthickness=2)
        # self.book_access_number_input_ent.insert(tk.END, '123456789') 
        self.book_access_number_input_ent.place(x=265, y=220, width=350)   
        # ------------------------------------------------------------------------------------------------------

        # 청구기호
        self.book_call_number_label = tk.Label(self.add_book_page_fm, text='청구기호', font='arial 14 bold')
        self.book_call_number_label.place(x=180, y=260)

        self.book_call_number_input_ent = tk.Entry(self.add_book_page_fm, font='arial 12', highlightbackground='#273b7a', highlightthickness=2)
        # self.book_call_number_input_ent.insert(tk.END, '김 책-이58ㅁ') 
        self.book_call_number_input_ent.place(x=265, y=260, width=350)   
        # ------------------------------------------------------------------------------------------------------

        # 소장위치
        self.book_location_label = tk.Label(self.add_book_page_fm, text='소장위치', font='arial 14 bold')
        self.book_location_label.place(x=180, y=300)

        self.book_location_input_ent = tk.Entry(self.add_book_page_fm, font='arial 12', highlightbackground='#273b7a', highlightthickness=2)
        self.book_location_input_ent.place(x=265, y=300, width=350)   
        # ------------------------------------------------------------------------------------------------------

        # 코드
        self.number_label = tk.Label(self.add_book_page_fm, text='바코드', font='arial 14 bold')
        self.number_label.place(x=180, y=340)

        self.number_input_ent = tk.Entry(self.add_book_page_fm, font='arial 12', highlightbackground='#273b7a', highlightthickness=2)
        # self.number_input_ent.insert(tk.END, '123456789') 
        self.number_input_ent.place(x=265, y=340, width=350)
        self.number_input_ent.bind('<Return>', self.input_entry_number)
        # ------------------------------------------------------------------------------------------------------

        # 코드 프레임
        self.add_number_pic_section_fm = tk.Frame(self.add_book_page_fm, highlightbackground=self.assets.bg_color, highlightthickness=2)
        self.add_number_pic_section_fm.place(x=265, y=380, width=350, height=50)
        # ------------------------------------------------------------------------------------------------------

        # 아래쪽 프레임
        self.bottom_frame = tk.Frame(self.add_book_page_fm, bg='#F5EBDD')
        self.bottom_frame.place(x=0, y=452)
        self.bottom_frame.configure(width=635, height=120)

        # 버튼
        self.forward_book_reg_btn = tk.Button(self.bottom_frame, text='도서 등록', font='arial 25 bold', bg='#6C6DFF',
                                             fg='white', bd=0, command=self.forwad_to_book_reg)
        self.forward_book_reg_btn.place(x=20, y=26)

        # 버튼
        self.forward_book_rag_document_btn = tk.Button(self.bottom_frame, text='문서 등록', font='arial 25 bold', bg='#8C61D8',
                                             fg='white', bd=0, command=self.forwad_to_book_document_rag)
        self.forward_book_rag_document_btn.place(x=235, y=26)

        # 버튼
        self.forward_welcome_btn = tk.Button(self.bottom_frame, text='시작 화면', font='arial 25 bold', bg='#FE853E',
                                             fg='white', bd=0, command=self.forwad_to_welcome_page)
        self.forward_welcome_btn.place(x=438, y=26)


    def input_entry_isbn(self, event):
        isbn = str(self.book_isbn_input_ent.get())
        print(isbn)

        get_book_data = naver_api.get_book_info(isbn)
        self.book_title_input_ent.insert(tk.END, get_book_data['title']) 
        self.book_author_input_ent.insert(tk.END, get_book_data['author'])
        self.book_publisher_input_ent.insert(tk.END, get_book_data['publisher']+' ' + get_book_data['pubdate'])
        
        self.url = get_book_data['image']

        # 이미지 요청 및 불러오기
        response = requests.get(self.url)
        img_data = response.content
        img = Image.open(BytesIO(img_data))

        # 이미지 크기를 100x100으로 조정
        img = img.resize((120, 120), Image.LANCZOS)

        # Tkinter에서 사용할 수 있는 이미지 객체로 변환
        self.book_img = ImageTk.PhotoImage(img)

        self.add_pic_btn.config(image=self.book_img)

    def input_entry_number(self, event):
        code = str(self.number_input_ent.get())
        print(code)

        # 바코드 생성 (이미지 파일로 저장)
        ean = barcode.get('code128', code, writer=ImageWriter())

        # 바코드 이미지를 파일로 저장 (PNG 형식)
        filename = ean.save("code_image/code")

        number_image = Image.open('code_image/code.png')
        resized_image_number = number_image.resize((350, 50), Image.LANCZOS)
        self.number_img = ImageTk.PhotoImage(resized_image_number)

        self.add_number_btn = tk.Button(self.add_number_pic_section_fm, image=self.number_img, bd=0)
        self.add_number_btn.pack()
            
    

    def forwad_to_book_reg(self):
        if self.book_isbn_input_ent.get()=='':
            messagebox.showwarning('입력', 'ISBN을 입력하세요')
        elif self.book_title_input_ent.get()=='':
            messagebox.showwarning('입력', '제목을 입력하세요')
        elif  self.book_author_input_ent.get()=='':
            messagebox.showwarning('입력', '저자를 입력하세요')
        elif self.book_publisher_input_ent.get()=='':
            messagebox.showwarning('입력', '출판사를 입력하세요')
        elif self.book_access_number_input_ent.get()=='':
            messagebox.showwarning('입력', '등록번호를 입력하세요')   
        elif self.book_call_number_input_ent.get() == '':
            messagebox.showwarning('입력', '청구기호를 입력하세요')        
        elif self.book_location_input_ent.get() == '':
            messagebox.showwarning('입력', '소장위치를 입력하세요')   
        elif self.number_input_ent.get() == '':
            messagebox.showwarning('입력', '바코드를 입력하세요')                                                        
        else:                       
            print(f'{self.book_title_input_ent.get()}')
            print(f'{self.book_author_input_ent.get()}')
            print(f'{self.book_publisher_input_ent.get()}')
            print(f'{self.url}')            
            print(f'{self.book_isbn_input_ent.get()}') 
            print(f'{self.book_access_number_input_ent.get()}')
            print(f'{self.book_call_number_input_ent.get()}')
            print(f'{self.book_location_input_ent.get()}')
            print(f'{self.number_input_ent.get()}')

            book_data = {
                'access_number': self.book_access_number_input_ent.get(), 
                'author': self.book_author_input_ent.get(), 
                'borrow_date': 'N', 
                'borrow_state': 'N', 
                'borrower_id': 'N', 
                'call_number': self.book_call_number_input_ent.get(), 
                'isbn':self.book_isbn_input_ent.get(), 
                'image': self.url, 
                'publisher': self.book_publisher_input_ent.get(), 
                'title': self.book_title_input_ent.get(),
                'location': self.book_location_input_ent.get(),
                'id': self.number_input_ent.get()
            }

            firebaseDB.set_book_info(book_data)
        

    def forwad_to_book_document_rag(self):
        self.add_book_page_fm.destroy()
        self.update()

        add_book_document_rag_fm = addBookRagPage.AddBookRagPage(self)
        add_book_document_rag_fm.pack()

    def forwad_to_welcome_page(self):
        self.add_book_page_fm.destroy()
        self.update()

        welcome_page_fm = welcomePage.WelcomePage(self)
        welcome_page_fm.pack()