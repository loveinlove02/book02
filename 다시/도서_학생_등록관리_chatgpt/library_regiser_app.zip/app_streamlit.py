from dotenv import load_dotenv
import os
import streamlit as st

from langchain_core.messages import ChatMessage
from langchain_openai import ChatOpenAI
from langchain.embeddings import OpenAIEmbeddings
from langchain.vectorstores import Chroma
from langchain_core.output_parsers import StrOutputParser
from langchain_core.output_parsers import CommaSeparatedListOutputParser
from langchain_core.prompts import PromptTemplate

load_dotenv(verbose=True)
key = os.getenv('OPENAI_API_KEY')


# OpenAI의 임베딩 모델(text-embedding-ada-002)을 초기화.
embeddings = OpenAIEmbeddings(
    openai_api_key=key,
    model='text-embedding-ada-002'
)

# Chroma 벡터 스토어를 초기화하고, 임베딩 데이터를 ./data 디렉토리에 저장.
database = Chroma(
    persist_directory = './data', 
    embedding_function = embeddings
)

st.title('💬 AI 도서관 Chatbot')
st.caption("🚀 AI chatbot 입니다")


# 처음 1번만 실행
if 'messages' not in st.session_state:
    # 대화기록을 저장하기 위한 용도
    st.session_state['messages'] = []

# 저장된 대화를 화면에 출력(이전 대화를 출력)
def print_messages():
    for chat_message in st.session_state['messages']:
        with st.chat_message(chat_message.role):
            st.write(chat_message.content)
# ----------------------------------------------------------------------

# 새로운 메시지를 추가
def add_message(role, message):
    st.session_state['messages'].append(ChatMessage(role=role, content=message))

def ask(query):  
    documents = database.similarity_search(query)	# 질문과 유사한 문서를 검색

    document_string = ''    

    for document in documents:						# 검색된 문서들을 document_string에 저장
        document_string += f"""
-------------------------------						
{document.page_content}
	"""
    template="""문장을 바탕으로 질문에 답하세요. 없으면 0이라고 답변하세요. 
    답변에는 제목, 저자, 발행처, isbn, 청구기호, 등록번호, 소장위치를 반듯이 넣어주세요.
    
    # 문장: {document}
    #질문: {query}
	"""

    prompt = PromptTemplate(
        template=template, 
        input_variables=['document', 'query']
    )

    llm = ChatOpenAI(
        api_key=key, 
        model='gpt-4o-mini',
        temperature=0
    )

    output_parser = StrOutputParser()
    
    chain = prompt | llm | output_parser

    return chain.invoke({'document': document_string, 'query': query})
# ----------------------------------------------------------------------

print_messages()

# 사용자 입력
user_input = st.chat_input('궁금한 내용을 물어보세요')

# 사용자 입력이 들어있으면
if user_input:
    with st.chat_message('user'):
        st.write(user_input)

    response = ask(user_input)

    if response!='0':

        with st.chat_message('assistant'):
            st.write(response)

        add_message('user', user_input)
        add_message('assistant', response)
    
    elif response=='0':
        # print('찾는 책은 없습니다')
        with st.chat_message('assistant'):
            st.write('찾는 책은 없습니다')

        add_message('user', user_input)
        add_message('assistant', '찾는 책은 없습니다')

