import firebase_admin
from firebase_admin import credentials
from firebase_admin import db, storage

cred = credentials.Certificate('firebase.json')
firebase_admin.initialize_app(cred, {
    'databaseURL': 'https://cho2-9857c.firebaseio.com/',
    'storageBucket' : 'cho2-9857c.appspot.com'
})

# 등록된 도서의 id를 리스트로 리턴
def get_book_id_list():
    ref = db.reference('library/book/')
    book_id_list = []

    for book_id in ref.get():
        book_id_list.append(book_id)

    return book_id_list
# ----------------------------------------------------------

# 등록된 책을 리스트로 가져온다
def get_book_list():    
    ref = db.reference('library/book/')
    book_dict = ref.get()

    book_id_list = get_book_id_list()
    book_list = []

    for book_id in book_id_list:
        title = book_dict[book_id]['title']
        author = book_dict[book_id]['author']
        publisher = book_dict[book_id]['publisher']
        borrow_state = book_dict[book_id]['borrow_state']
        book_list.append((title, author, publisher, book_id, "대출가능" if borrow_state=="N" else '대출중'))
    
    return book_list
# ----------------------------------------------------------

# 책 1권의 정보를 딕셔너리로 가져온다
def get_book_info(id):
    ref = db.reference('library/book/'+ id)
    book_info_dict = ref.get()

    return book_info_dict
# ----------------------------------------------------------

def set_book_info(book_data):
    ref = db.reference('library/book/'+ book_data['id'])
    ref.set(book_data)   
# ----------------------------------------------------------

def get_all_book():
    ref = db.reference('library/book/')
    book_dict = ref.get()

    f = open('data_document/book_document.txt', 'w', encoding='utf-8')

    for book_id, book in book_dict.items():
        title = book['title']
        author = book['author']
        publisher = book['publisher']
        call_number = book['call_number']
        access_number = book['access_number']
        location = book['location']
        isbn = book['isbn']

        print(f'### 제목 : {title}')
        print(f'- 저자 : {author}')
        print(f'- 발행처 : {publisher}')
        print(f'- isbn : {isbn}')
        print(f'- 청구기호 : {call_number}')
        print(f'- 등록번호 : {access_number}')
        print(f'- 소장위치 : {location}')
        print()
        print()

        f.write(f'### 제목 : {title}\n')
        f.write(f'- 저자 : {author}\n')
        f.write(f'- 발행처 : {publisher}\n')
        f.write(f'- isbn : {isbn}\n')
        f.write(f'- 청구기호 : {call_number}\n')
        f.write(f'- 등록번호 : {access_number}\n')
        f.write(f'- 소장위치 : {location}\n')
        f.write('\n\n')

    f.close()

    return True



def get_student_id():
    ref = db.reference('library/member/')

    student_id_list = []

    for id in ref.get():
        student_id_list.append(id)
        
    return student_id_list


def get_student_info():
    student_id = get_student_id()
    stuent_list = []
    
    ref = db.reference('library/member/')
    student_dict = ref.get()

    for id in student_id:
        stu_id = student_dict[id]['id']
        stu_pw = student_dict[id]['pw']
        stu_name = student_dict[id]['name']
        stu_grade = student_dict[id]['grade']
        stu_class = student_dict[id]['class']
        stu_num = student_dict[id]['num']
        
        # print(stu_id, stu_pw, stu_name, stu_grade, stu_class, stu_num)
        stuent_list.append((stu_id, stu_pw, stu_name, stu_grade, stu_class, stu_num))

    return stuent_list       


def upload_image(image_path, remote_path):
    bucket = storage.bucket()
    blob = bucket.blob(remote_path)
    blob.upload_from_filename(image_path)
    print("Image uploaded successfully.")


def set_student_info(student_info_data):
    ref = db.reference('library/member/'+ student_info_data['id'])
    ref.set(student_info_data)

    

    