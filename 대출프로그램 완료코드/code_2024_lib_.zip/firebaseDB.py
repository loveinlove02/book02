import firebase_admin
from firebase_admin import credentials
from firebase_admin import db, storage

from datetime import datetime

cred = credentials.Certificate('firebase3.json')
firebase_admin.initialize_app(cred, {
    'databaseURL': 'https://water-7f5cb.firebaseio.com/',
    'storageBucket' : 'water-7f5cb.appspot.com'
})


def verify_student(code):
    ref = db.reference('library/member/' + code)
    return ref.get()



def get_student_id():
    ref = db.reference('library/member')
    users_id = list(ref.get().keys())

    return users_id


def download_image():
    ref = db.reference('library/member')
    users_id = list(ref.get().keys())

    bucket = storage.bucket()
    local_path = 'download_image'

    for remote_path in users_id:
        print(remote_path)
        get_blob = bucket.blob(remote_path + '.jpg')
        get_blob.download_to_filename(local_path + '/' + remote_path + '.jpg')
        # print(remote_path + '.jpg', '다운로드')

def get_student_password(student_id):
    # student_id = 'stud_02_02_008'
    ref = db.reference('library/member/' + student_id)
    return ref.get()['pw']



def get_book_isbn():
    ref = db.reference('library/book/')
    book_dict = ref.get()
    
    book_isbn_list = []

    for isbn in book_dict:
        book_isbn_list.append(isbn)

    return book_isbn_list


def get_book_info(isbn):
    ref = db.reference('library/book/' + isbn)
    book_info_dict = ref.get()

    return book_info_dict


def borrow_book(book_dict, user_id):
    
    now = datetime.now()
    borrow_date = now.strftime('%Y-%m-%d %H:%M')

    for isbn in book_dict:
        ref = db.reference('library/book/'+ isbn)
        # print(ref.get()['borrow_date'], ref.get()['borrow_state'], ref.get()['borrower_id'])
        ref.update({
            'borrow_date': borrow_date,
            'borrow_state': 'Y',
            'borrower_id': user_id
        })
        


def return_book(book_dict):
    for isbn in book_dict:
        ref = db.reference('library/book/'+ isbn)

        ref.update({
            'borrow_date': 'N',
            'borrow_state': 'N',
            'borrower_id': 'N'
        })

