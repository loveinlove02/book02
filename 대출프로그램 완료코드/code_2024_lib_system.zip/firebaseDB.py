import firebase_admin
from firebase_admin import credentials
from firebase_admin import db, storage

cred = credentials.Certificate('firebase3.json')
firebase_admin.initialize_app(cred, {
    'databaseURL': 'https://water-7f5cb.firebaseio.com/',
    'storageBucket' : 'water-7f5cb.appspot.com'
})


# 등록된 도서의 isbn을 리스트로 리턴
def get_book_isbn():
    ref = db.reference('library/book/')
    isbn_list = []

    for isbn in ref.get():
        isbn_list.append(isbn)
    
    return isbn_list


# 등록된 도서를 
def get_book_list():
    book_list = []

    ref = db.reference('library/book/')
    book_dict = ref.get()

    book_isbn_list = get_book_isbn()

    for isbn in book_isbn_list:
        title = book_dict[isbn]['title']
        author = book_dict[isbn]['author']
        publisher = book_dict[isbn]['publisher']
        call_number = book_dict[isbn]['call_number']
        access_number = book_dict[isbn]['access_number']
        borrow_date = book_dict[isbn]['borrow_date']
        borrow_state = book_dict[isbn]['borrow_state']
        borrower_id = book_dict[isbn]['borrower_id']
        
        book_list.append((title, author, publisher, isbn, "대출가능" if borrow_state=="N" else '대출중'))
        # print(f'{title} {author} {publisher} {call_number} {access_number} {borrow_date} {borrow_state} {borrower_id}')

    
    return book_list


def get_book_info(isbn):
    ref = db.reference('library/book/'+ isbn)
    book_info_dict = ref.get()

    return book_info_dict


def set_book_info(book_data):
    ref = db.reference('library/book/'+ book_data['isbn'])
    ref.set(book_data)


def get_student_id():
    ref = db.reference('library/member/')

    student_id_list = []

    for id in ref.get():
        student_id_list.append(id)
        
    return student_id_list


def get_student_info():
    student_id = get_student_id()
    stuent_list = []
    
    ref = db.reference('library/member/')
    student_dict = ref.get()

    for id in student_id:
        stu_id = student_dict[id]['id']
        stu_pw = student_dict[id]['pw']
        stu_name = student_dict[id]['name']
        stu_grade = student_dict[id]['grade']
        stu_class = student_dict[id]['class']
        stu_num = student_dict[id]['num']
        
        # print(stu_id, stu_pw, stu_name, stu_grade, stu_class, stu_num)
        stuent_list.append((stu_id, stu_pw, stu_name, stu_grade, stu_class, stu_num))

    return stuent_list       


def upload_image(image_path, remote_path):
    bucket = storage.bucket()
    blob = bucket.blob(remote_path)
    blob.upload_from_filename(image_path)
    print("Image uploaded successfully.")


def set_student_info(student_info_data):
    ref = db.reference('library/member/'+ student_info_data['id'])
    ref.set(student_info_data)


'''
{'access_number': 'CRX000029216', 
 'author': '이승찬', 
 'borrow_date': 'N', 
 'borrow_state': 'N', 
 'borrower_id': 'N', 
 'call_number': '일 005.12-이58ㅁ', 
 'isbn': 9791160505856, 
 'location': 'https://raw.githubusercontent.com/loveinlove02/book01/main/image/loc_b.png', 
 'publisher': '길벗 2017', 
 'title': '모두의 파이썬'}
'''

# get_book_list()

# def verify_student(code):
#     ref = db.reference('library/member/' + code)
#     return ref.get()

# def get_student_id():
#     ref = db.reference('library/member')
#     users_id = list(ref.get().keys())

#     return users_id


# def download_image():
#     ref = db.reference('library/member')
#     users_id = list(ref.get().keys())

#     bucket = storage.bucket()
#     local_path = 'download_image'

#     for remote_path in users_id:
#         print(remote_path)
#         get_blob = bucket.blob(remote_path + '.jpg')
#         get_blob.download_to_filename(local_path + '/' + remote_path + '.jpg')
#         # print(remote_path + '.jpg', '다운로드')

# def get_student_password(student_id):
#     # student_id = 'stud_02_02_008'
#     ref = db.reference('library/member/' + student_id)
#     return ref.get()['pw']
