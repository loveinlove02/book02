import tkinter as tk
import assets as asset


class BookListPage(tk.Frame):
    def __init__(self, container):
        super().__init__(container)

        self.assets = asset.Assets()
        self.create_widgets()

    def create_widgets(self):
        self.book_list_page_fm = tk.Frame(self, highlightbackground=self.assets.bg_color, highlightthickness=2)
        self.book_list_page_fm.pack(pady=10)
        self.book_list_page_fm.configure(width=640, height=580)


# root = tk.Tk()
# root.title("Book List")
# root.geometry("650x600")

# book_list_page = BookListPage(root)
# book_list_page.pack(fill="both", expand=True)
# root.mainloop()
