import tkinter as tk
import assets as asset

class WelcomePage(tk.Frame):
    def __init__(self, container):
        super().__init__(container)

        self.assets = asset.Assets()
        self.create_widgets()

    def create_widgets(self):
        self.welcome_page_fm = tk.Frame(self, highlightbackground=self.assets.bg_color, highlightthickness=2)
        self.welcome_page_fm.pack(pady=10)
        self.welcome_page_fm.configure(width=640, height=580)








# root = tk.Tk()
# root.title("Welcome Page")
# root.geometry("650x600")

# welcome_page = WelcomePage(root)
# welcome_page.pack(fill="both", expand=True)
# root.mainloop()

