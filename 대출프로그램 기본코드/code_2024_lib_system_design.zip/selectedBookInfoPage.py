import tkinter as tk
import assets as asset

class SelectedBookInfoPage(tk.Frame):
    def __init__(self, container, isbn):
        super().__init__(container)
 
        self.assets = asset.Assets()
        self.create_widgets()

    def create_widgets(self):
        self.selected_book_info_page_fm = tk.Frame(self, highlightbackground=self.assets.bg_color, highlightthickness=2)
        self.selected_book_info_page_fm.pack(pady=10)
        self.selected_book_info_page_fm.configure(width=640, height=580)


# root = tk.Tk()
# root.title("SElected Book")
# root.geometry("650x600")

# welcome_page = SelectedBookInfoPage(root, '123456789')
# welcome_page.pack(fill="both", expand=True)
# root.mainloop()
