import tkinter as tk

class Assets():
    def __init__(self):
        self.bg_color = '#273b7a'
        self.title_color = '#BDC3DE'