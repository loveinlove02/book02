pip install numpy==1.26.4

pip install opencv-contrib-python
pip install firebase_admin
pip install pillow
pip install requests
pip install pandas


